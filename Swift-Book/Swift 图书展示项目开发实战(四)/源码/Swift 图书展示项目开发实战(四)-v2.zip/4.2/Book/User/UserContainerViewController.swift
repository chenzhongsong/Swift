//
//  UserContainerViewController.swift
//  Book
//
//  Created by bo on 16/2/20.
//  Copyright © 2016年 jikexueyuan. All rights reserved.
//

import UIKit

class UserContainerViewController: UIViewController {

    @IBAction func back(sender: AnyObject) {
        navigationController?.popViewControllerAnimated(true)
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

 

}
